# CyberShield — Dual-Model Cybersecurity Threat Classifier

This Flask website runs the two project models, not JavaScript keyword rules:

- Method 1: DistilBERT + LoRA (`distilbert-base-uncased`), WordPiece tokenizer, 64-token input, 4-class head.
- Method 2: 2-layer BiLSTM, 128-d embedding, 128 hidden units per direction, 64-word input, vocabulary from the training notebook.

## Important: model artifacts are required

The two model ZIP files have now been added to this project. Method-1 includes its LoRA adapter, tokenizer and classifier. Method-2 includes its BiLSTM weights and vocabulary. The site loads these files directly and reports a model as unavailable if loading fails.

Expected files:

```text
models/
  method1/
    adapter_config.json
    adapter_model.safetensors   (or adapter_model.bin)
    classifier.pt
    tokenizer_config.json
    vocab.txt
    special_tokens_map.json     (plus tokenizer files saved by HF)
  method2/
    method2_bilstm_model.pt
    vocab.json
```

## Export Method 1

Run the Method-1 notebook through the end of training. Its existing training script already saves the LoRA adapter, tokenizer and classifier in `local_model/`. Download that folder from Colab and copy its contents into `models/method1/`.

In Colab:

```python
!zip -r method1_model.zip local_model
from google.colab import files
files.download("method1_model.zip")
```

Extract the downloaded ZIP and copy the contents of `local_model/` into `models/method1/`.

## Export Method 2 — critical notebook fix

The supplied Method-2 notebook contains repeated fallback/re-initialization cells after the training loop. Those cells can create a fresh, untrained model before later evaluation/saving. Save the trained model and its exact vocabulary immediately after the training loop finishes (before any re-initialization cell).

Add and run this cell immediately after the cell that completes the 5-epoch training loop:

```python
import json, os, torch
os.makedirs("method2_export", exist_ok=True)

# Save the exact trained weights and vocabulary from this training run.
torch.save(model.state_dict(), "method2_export/method2_bilstm_model.pt")
with open("method2_export/vocab.json", "w", encoding="utf-8") as f:
    json.dump(vocab, f, ensure_ascii=False)

!zip -r method2_model.zip method2_export
from google.colab import files
files.download("method2_model.zip")
```

Do not rebuild `vocab` between training and export. The vocabulary indices must match the embedding rows in the checkpoint. Do not run a cell that reinitializes `model` before this export cell.

Extract the ZIP and copy both files into `models/method2/`.

## Run locally

Python 3.10 or 3.11 is recommended.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

The page shows model readiness indicators. Select Method 1, Method 2, or Compare both. When both are selected, the page reports whether the model predictions agree.

## API

`POST /api/predict`

```json
{"text":"Multiple failed SSH login attempts from an unknown IP","mode":"both"}
```

`mode` can be `method1`, `method2`, or `both`.

`GET /api/status` reports which model artifacts were successfully loaded.

## Research note

The models predict one of the four labels learned during training: intrusion, phishing, malware, normal. This is a project prototype and not a production security product. Method-1's reported held-out test accuracy in the current notebook run was 75.00%. Method-2's notebook must be checked carefully: it includes fallback code that may reinitialize the model after training, so the saved checkpoint must be exported directly after the training loop. The 100% dummy-data result in the Method-2 report is not valid real-dataset performance.


## Method-2 data provenance warning

The uploaded Method-2 vocabulary has 222 entries and contains template phrases such as `this is an example of intrusion event`, with similar generic examples for the other classes. This matches the earlier dummy-data run described in the project report. The website displays a warning accordingly. Retrain Method-2 with the actual `dataset.csv`, then replace both files in `models/method2/` before treating its predictions or metrics as valid.

## Publish online (no installation for visitors)

See [DEPLOY_ONLINE.md](DEPLOY_ONLINE.md). This project includes `render.yaml` and a Gunicorn start command for cloud deployment. After you deploy it, share the public HTTPS URL; visitors do not need to install Python or download the model files. Cloud hosting may cost money, and the first deployment downloads the DistilBERT base model.
