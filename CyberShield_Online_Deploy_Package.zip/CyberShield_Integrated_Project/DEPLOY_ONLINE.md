# Put CyberShield online (visitors need no installation)

This project is prepared for a cloud-hosted Flask deployment. Once deployed, people can open its public HTTPS URL in a browser. They do not need Python, model files, or a local server.

## Before deployment

- You need a GitHub account and a Render account.
- Upload this complete project folder to a **private GitHub repository** (recommended because it contains your model artifacts), or use another trusted Git provider.
- Keep the `models/` folder and all its files in the repository. Do not omit the model weights.
- The first deployment downloads the public `distilbert-base-uncased` base model from Hugging Face, so the cloud service needs outbound internet access.

## Deploy with Render Blueprint

1. Sign in to GitHub and create a new **private** repository, for example `cybershield-dual-model`.
2. Upload all files and folders from this project into the repository root. Ensure `render.yaml`, `app.py`, `requirements.txt`, `templates/`, `static/`, and `models/` are at the root level.
3. Sign in to Render and choose **New → Blueprint**.
4. Connect GitHub, select the repository, and review the `render.yaml` settings.
5. Create the service and wait for the build and first model download to finish. The first start can take several minutes.
6. When Render reports the service as Live, open the `onrender.com` URL it gives you. Share that URL; visitors only need a browser.

## Important hosting notes

- The included Render configuration selects a Standard-sized instance because loading PyTorch and DistilBERT can exceed the memory available on small free instances. Hosting may incur charges; check the provider's current pricing before creating the service.
- The service runs one Gunicorn worker to reduce memory usage. Cold starts/restarts may reload the model and take time.
- Do not put secrets or private datasets in a public repository. This project does not require API keys.
- The Method-2 checkpoint currently appears to have been trained on template/dummy examples. The website warns about this. Retrain Method 2 on the real project dataset before presenting its predictions as validated results.
- This is a student project prototype, not a production security monitoring service. Do not upload confidential logs or personal data to a publicly accessible demo.

## Local development

`python app.py` still works on your own computer. For public access, use the cloud URL created by Render rather than `127.0.0.1`.
