# RUN THIS CELL IMMEDIATELY AFTER THE METHOD-2 TRAINING LOOP
# This preserves the exact trained weights and vocabulary used by the model.
import json, os, torch
os.makedirs("method2_export", exist_ok=True)
torch.save(model.state_dict(), "method2_export/method2_bilstm_model.pt")
with open("method2_export/vocab.json", "w", encoding="utf-8") as f:
    json.dump(vocab, f, ensure_ascii=False)
!zip -r method2_model.zip method2_export
from google.colab import files
files.download("method2_model.zip")
