const $ = (id) => document.getElementById(id);
const input = $("message"), count = $("char-count"), analyze = $("analyze");
input.addEventListener("input", () => count.textContent = input.value.length);
$("clear").addEventListener("click", () => { input.value = ""; count.textContent = "0"; input.focus(); $("results").hidden = true; $("error").hidden = true; });
document.querySelectorAll("[data-example]").forEach(btn => btn.addEventListener("click", () => { input.value = btn.dataset.example; count.textContent = input.value.length; input.focus(); }));
async function loadStatus(){
  try{
    const r=await fetch("/api/status"); const s=await r.json();
    $("m1-dot").classList.toggle("ready",s.method1.loaded);
    $("m2-dot").classList.toggle("ready",s.method2.loaded);
    if(s.method2.warning){
      $("model-warning").textContent = "Method-2 dataset warning: " + s.method2.warning;
      $("model-warning").hidden = false;
    }
  }catch(e){}
}
function pct(v){return Number(v).toFixed(2)+"%"}
function renderCard(name,data){
 const title=name==="method1"?"METHOD 1 · DISTILBERT + LORA":"METHOD 2 · BILSTM";
 const rows=Object.entries(data.probabilities).map(([label,value])=>`<div class="prob-row"><span>${label}</span><div class="track"><div class="fill" style="width:${value}%"></div></div><span class="prob-value">${pct(value)}</span></div>`).join("");
 return `<article class="result-card"><div class="result-title"><span>${title}</span><span>MODEL OUTPUT</span></div><div class="verdict">${data.label}</div><div class="confidence">CONFIDENCE · ${pct(data.confidence)}</div>${rows}</article>`;
}
analyze.addEventListener("click", async()=>{
 const text=input.value.trim(), mode=$("mode").value;
 $("error").hidden=true;
 if(!text){$("error").textContent="Enter a message or log entry first."; $("error").hidden=false;return;}
 analyze.disabled=true; analyze.querySelector("span").textContent="Analyzing…";
 try{
   const response=await fetch("/api/predict",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text,mode})});
   const data=await response.json();
   if(!response.ok) throw new Error(data.error||"Prediction failed.");
   const entries=Object.entries(data.results);
   $("result-grid").innerHTML=entries.map(([k,v])=>renderCard(k,v)).join("");
   $("agreement").hidden=entries.length<2;
   if(entries.length===2){
     const agree=data.agreement;
     $("agreement").className="agreement"+(agree?"":" disagree");
     $("agreement").textContent=agree?"✓ Both models agree on: "+entries[0][1].label.toUpperCase():"⚠ Models disagree — Method 1 predicts "+entries[0][1].label+" while Method 2 predicts "+entries[1][1].label+". Review the input and supporting evidence.";
   }
   $("device-label").textContent="INFERENCE DEVICE · "+data.device.toUpperCase();
   $("results").hidden=false; $("results").scrollIntoView({behavior:"smooth",block:"start"});
 }catch(err){$("error").textContent=err.message; $("error").hidden=false;}
 finally{analyze.disabled=false;analyze.querySelector("span").textContent="Run detection";}
});
loadStatus();
