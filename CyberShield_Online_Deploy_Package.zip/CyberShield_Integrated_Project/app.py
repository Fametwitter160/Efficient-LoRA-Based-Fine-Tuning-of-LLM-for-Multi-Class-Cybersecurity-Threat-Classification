import os, json, re
from pathlib import Path

import torch
import torch.nn as nn
from flask import Flask, render_template, request, jsonify
from transformers import DistilBertModel, DistilBertTokenizerFast
from peft import PeftModel

BASE_DIR = Path(__file__).resolve().parent
M1_DIR = BASE_DIR / "models" / "method1"
M2_DIR = BASE_DIR / "models" / "method2"
LABELS = ["intrusion", "phishing", "malware", "normal"]
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

app = Flask(__name__)

class BiLSTMClassifier(nn.Module):
    def __init__(self, vocab_size, embedding_dim=128, hidden_dim=128,
                 num_layers=2, num_classes=4, dropout=0.3):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.lstm = nn.LSTM(
            input_size=embedding_dim, hidden_size=hidden_dim,
            num_layers=num_layers, batch_first=True,
            bidirectional=True, dropout=dropout
        )
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_dim * 2, num_classes)

    def forward(self, x):
        embedded = self.embedding(x)
        _, (hidden, _) = self.lstm(embedded)
        forward_hidden, backward_hidden = hidden[-2], hidden[-1]
        combined = torch.cat((forward_hidden, backward_hidden), dim=1)
        return self.classifier(self.dropout(combined))

class ModelService:
    def __init__(self):
        self.m1 = None
        self.m2 = None
        self.m1_error = None
        self.m2_error = None
        self._load_method1()
        self._load_method2()

    def _load_method1(self):
        try:
            required = [M1_DIR / "adapter_config.json", M1_DIR / "classifier.pt"]
            if not all(p.exists() for p in required):
                raise FileNotFoundError("Method-1 files missing. Export local_model from the Method-1 Colab notebook into models/method1/.")
            self.tokenizer1 = DistilBertTokenizerFast.from_pretrained(str(M1_DIR))
            base = DistilBertModel.from_pretrained("distilbert-base-uncased")
            encoder = PeftModel.from_pretrained(base, str(M1_DIR))
            classifier = nn.Linear(768, 4)
            classifier.load_state_dict(torch.load(M1_DIR / "classifier.pt", map_location="cpu", weights_only=True))
            self.m1 = (encoder.to(DEVICE).eval(), classifier.to(DEVICE).eval())
        except Exception as exc:
            self.m1_error = str(exc)

    def _load_method2(self):
        try:
            vocab_path = M2_DIR / "vocab.json"
            weights_path = M2_DIR / "method2_bilstm_model.pt"
            if not vocab_path.exists() or not weights_path.exists():
                raise FileNotFoundError("Method-2 files missing. Export vocab.json and method2_bilstm_model.pt from the Method-2 Colab notebook into models/method2/.")
            self.vocab = json.loads(vocab_path.read_text(encoding="utf-8"))
            self.model2 = BiLSTMClassifier(vocab_size=len(self.vocab))
            state = torch.load(weights_path, map_location="cpu", weights_only=True)
            self.model2.load_state_dict(state)
            self.model2.to(DEVICE).eval()
        except Exception as exc:
            self.m2_error = str(exc)

    def predict_method1(self, text):
        encoder, classifier = self.m1
        encoded = self.tokenizer1(
            text, truncation=True, padding="max_length",
            max_length=64, return_tensors="pt"
        )
        encoded = {k: v.to(DEVICE) for k, v in encoded.items()}
        with torch.no_grad():
            output = encoder(**encoded)
            vector = output.last_hidden_state[:, 0, :]
            logits = classifier(vector)
            probs = torch.softmax(logits, dim=1)[0].cpu().tolist()
        return probs

    def predict_method2(self, text):
        tokens = text.lower().split()
        seq = [self.vocab.get(token, self.vocab.get("<UNK>", 1)) for token in tokens[:64]]
        seq += [self.vocab.get("<PAD>", 0)] * (64 - len(seq))
        x = torch.tensor([seq], dtype=torch.long, device=DEVICE)
        with torch.no_grad():
            logits = self.model2(x)
            probs = torch.softmax(logits, dim=1)[0].cpu().tolist()
        return probs

service = ModelService()

@app.get("/")
def home():
    return render_template("index.html", device=str(DEVICE))

@app.get("/api/status")
def status():
    return jsonify({
        "device": str(DEVICE),
        "method1": {"loaded": service.m1 is not None, "error": service.m1_error},
        "method2": {
            "loaded": service.m2 is not None,
            "error": service.m2_error,
            "warning": "The supplied vocabulary contains template phrases such as 'this is an example of intrusion event'. This matches the earlier dummy-data run. Retrain Method-2 on the real project dataset before treating its predictions or metrics as valid."
        }
    })

@app.post("/api/predict")
def predict():
    data = request.get_json(silent=True) or {}
    text = (data.get("text") or "").strip()
    mode = data.get("mode", "both")
    if not text:
        return jsonify({"error": "Enter a message or log entry to analyze."}), 400
    if len(text) > 5000:
        return jsonify({"error": "Please keep the input under 5,000 characters."}), 400

    results = {}
    if mode in ("method1", "both"):
        if service.m1 is None:
            return jsonify({"error": "Method-1 is not ready: " + str(service.m1_error)}), 503
        probs = service.predict_method1(text)
        results["method1"] = make_result(probs)
    if mode in ("method2", "both"):
        if service.m2 is None:
            return jsonify({"error": "Method-2 is not ready: " + str(service.m2_error)}), 503
        probs = service.predict_method2(text)
        results["method2"] = make_result(probs)

    predictions = [v["label"] for v in results.values()]
    return jsonify({
        "results": results,
        "agreement": (predictions[0] == predictions[1]) if len(predictions) == 2 else None,
        "device": str(DEVICE)
    })

def make_result(probs):
    index = max(range(len(probs)), key=lambda i: probs[i])
    return {
        "label": LABELS[index],
        "confidence": round(float(probs[index]) * 100, 2),
        "probabilities": {LABELS[i]: round(float(probs[i]) * 100, 2) for i in range(4)}
    }

if __name__ == "__main__":
    # Local development; cloud hosts provide PORT and bind to all interfaces.
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
