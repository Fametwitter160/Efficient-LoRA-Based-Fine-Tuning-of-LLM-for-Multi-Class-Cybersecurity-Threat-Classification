# Fraud & Threat Text Detector (Flask)

Paste text into the website -> it is classified as **Phishing/Fraud, Malware, Intrusion or Normal**.

## Run
```bash
pip install flask            # enough for the built-in rule engine
python app.py                # open http://localhost:5000
```

## Use your trained DistilBERT + LoRA model
```bash
pip install -r requirements.txt
```
1. Save your adapter after training: `model.save_pretrained("model")` (creates `adapter_config.json` + weights).
2. Put that folder at `fraud_app/model/` (or set `MODEL_DIR=/path/to/folder`).
3. If your label order is not `["Intrusion","Phishing","Malware","Normal"]`, add `model/labels.json`,
   e.g. `["Intrusion","Phishing","Malware","Normal"]` in the exact order used in training.
4. Restart. `GET /api/health` shows `"engine": "distilbert-lora"` when it loaded.
   Base model defaults to `distilbert-base-uncased` (override with `BASE_MODEL`).
   If your classification head was saved separately, load it in `load_bert()`.

## API
`POST /api/predict` with `{"text": "..."}` returns label, verdict, risk, confidence, probabilities, signals, engine.
