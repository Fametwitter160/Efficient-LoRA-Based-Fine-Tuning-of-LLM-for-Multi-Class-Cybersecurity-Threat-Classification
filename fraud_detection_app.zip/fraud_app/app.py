"""Fraud / threat text detector - Flask web app.

Type or paste any message, log line or alert into the website and it is classified as
Phishing/Fraud, Malware, Intrusion or Normal.

Two engines:
  1. "distilbert-lora": your trained DistilBERT + LoRA model (used automatically when the
     adapter folder exists, see README).
  2. "rules": an explainable keyword/pattern engine used when no trained model is present.
"""
import json
import math
import os
import re

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
MAX_CHARS = 2000
LABELS = ["Intrusion", "Phishing", "Malware", "Normal"]  # default order, override via labels.json

# ----------------------------------------------------------------------------------
# Engine 1: trained DistilBERT + LoRA (optional)
# ----------------------------------------------------------------------------------
MODEL_DIR = os.environ.get("MODEL_DIR", os.path.join(os.path.dirname(__file__), "model"))
BASE_MODEL = os.environ.get("BASE_MODEL", "distilbert-base-uncased")
_bert = None


def load_bert():
    """Load the LoRA adapter if MODEL_DIR exists. Returns None on any problem."""
    global LABELS
    if not os.path.isdir(MODEL_DIR):
        return None
    try:
        import torch
        from peft import PeftModel
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        labels_file = os.path.join(MODEL_DIR, "labels.json")
        if os.path.exists(labels_file):
            with open(labels_file) as f:
                LABELS = json.load(f)
        tok = AutoTokenizer.from_pretrained(BASE_MODEL)
        base = AutoModelForSequenceClassification.from_pretrained(BASE_MODEL, num_labels=len(LABELS))
        model = PeftModel.from_pretrained(base, MODEL_DIR).eval()
        print(f"[engine] DistilBERT+LoRA loaded from {MODEL_DIR}")
        return tok, model, torch
    except Exception as exc:  # noqa: BLE001
        print(f"[engine] could not load trained model ({exc}); using rule engine")
        return None


def predict_bert(text):
    tok, model, torch = _bert
    enc = tok(text, truncation=True, max_length=64, padding="max_length", return_tensors="pt")
    with torch.no_grad():
        probs = torch.softmax(model(**enc).logits, dim=-1)[0].tolist()
    return dict(zip(LABELS, probs)), []


# ----------------------------------------------------------------------------------
# Engine 2: explainable rule engine
# ----------------------------------------------------------------------------------
# (regex, weight, human-readable reason)
RULES = {
    "Phishing": [
        (r"\b(urgent|immediately|act now|right away|last warning|final notice|within \d+ hours?)\b", 1.2, "Creates urgency or pressure"),
        (r"\b(verify|confirm|update|validate)\b.{0,30}\b(account|identity|details|password|card|kyc|bank)\b", 2.0, "Asks you to verify account or personal details"),
        (r"\b(otp|one[- ]time (password|code)|cvv|pin|password|passcode)\b", 1.8, "Asks for or mentions secret codes/credentials"),
        (r"\b(you('ve| have) (won|been selected)|lottery|prize|jackpot|congratulations)\b", 2.2, "Prize / lottery lure"),
        (r"\b(claim|collect)\b.{0,20}\b(reward|refund|prize|gift)\b", 1.6, "Asks you to claim a reward or refund"),
        (r"\b(gift cards?|wire transfer|western union|crypto(currency)?|bitcoin|upi)\b.{0,40}\b(send|pay|transfer|buy)\b|\b(send|pay|transfer|buy)\b.{0,40}\b(gift cards?|wire transfer|western union|bitcoin|upi)\b", 2.2, "Requests payment in a hard-to-trace way"),
        (r"\b(processing|clearance|release|customs|registration) fee\b", 2.0, "Advance-fee request"),
        (r"\b(account|card|wallet)\b.{0,30}\b(suspended|blocked|locked|deactivated|compromised|closed)\b", 2.0, "Claims your account is suspended or compromised"),
        (r"https?://\S*(bit\.ly|tinyurl|t\.co|goo\.gl|cutt\.ly|rb\.gy)\S*|https?://\d{1,3}(\.\d{1,3}){3}", 2.0, "Contains a shortened or IP-address link"),
        (r"https?://\S+", 0.8, "Contains a link"),
        (r"\b(click|tap|open)\b.{0,20}\b(link|here|below)\b", 1.2, "Tells you to click a link"),
        (r"\b(paypal|amazon|netflix|apple|microsoft|hdfc|sbi|icici|irs|fedex|dhl|customs)\b.{0,60}\b(suspend|verify|locked|refund|fee|unusual|problem)\b", 1.5, "Brand impersonation pattern"),
        (r"\b(investment|trading|crypto)\b.{0,40}\b(double|guaranteed|100%|daily returns?|risk[- ]free)\b", 2.2, "Guaranteed-returns investment scam"),
        (r"\b(dear (customer|user|sir|madam|winner)|beneficiary)\b", 0.8, "Generic greeting typical of mass scams"),
    ],
    "Malware": [
        (r"\.(exe|scr|bat|vbs|jar|apk|msi|js)\b", 2.0, "Mentions an executable / script file"),
        (r"\b(ransomware|trojan|keylogger|spyware|botnet|rootkit|backdoor|worm|cryptominer)\b", 2.8, "Names a malware family or type"),
        (r"\b(files? (have been|are|were) encrypted|encrypted your files|decrypt(ion)? key|pay.{0,20}ransom)\b", 3.0, "Ransom-note wording"),
        (r"\b(enable (macros?|content)|macro[- ]enabled)\b", 2.4, "Asks to enable macros"),
        (r"\b(download|install)\b.{0,30}\b(and|then)?\s*(run|execute|open)\b", 1.8, "Tells you to download and run something"),
        (r"powershell.{0,15}-(enc|encodedcommand)|cmd(\.exe)?\s*/c|base64 -d|certutil -urlcache", 2.8, "Obfuscated command execution"),
        (r"\b(payload|shellcode|dropper|c2 server|command and control|malicious (file|attachment|payload|macro))\b", 2.4, "Technical malware indicators"),
        (r"\b(attachment|attached)\b.{0,40}\.(zip|rar|7z|iso|docm|xlsm)\b", 1.8, "Suspicious archive/macro attachment"),
    ],
    "Intrusion": [
        (r"\b(failed|invalid|incorrect) (login|password|authentication|attempts?)\b", 2.0, "Failed authentication attempts"),
        (r"\b(\d{2,}|multiple|repeated|many) (failed|invalid|unsuccessful)\b", 1.8, "Repeated failures"),
        (r"\b(brute[- ]?force|credential stuffing|password spray(ing)?)\b", 2.8, "Brute-force style attack"),
        (r"\b(port scan(ning)?|nmap|syn flood|ddos|denial of service)\b", 2.8, "Scanning / flooding activity"),
        (r"\b(unauthori[sz]ed (access|login|connection)|access denied|permission denied)\b", 2.0, "Unauthorised access"),
        (r"\b(sql injection|xss|cross[- ]site|directory traversal|remote code execution|rce|exploit(ed|ation)?|cve-\d{4}-\d+)\b", 2.8, "Exploit / injection indicator"),
        (r"\b(privilege escalation|root (login|access|shell)|sudo|admin login from)\b", 2.2, "Privilege escalation"),
        (r"\b(ssh|rdp|telnet|ftp)\b.{0,40}\b(from|login|connection|attempt)\b", 1.0, "Remote-access service activity"),
        (r"\b(suspicious|anomalous|unusual)\b.{0,30}\b(traffic|connection|login|activity|ip)\b", 1.6, "Flagged as suspicious/anomalous"),
        (r"\bfrom (ip )?\d{1,3}(\.\d{1,3}){3}\b", 0.8, "Activity from a specific remote IP"),
    ],
    "Normal": [
        (r"\b(meeting|lunch|schedule[d]?|agenda|minutes|thanks|thank you|regards|cheers|see you|good morning|hello|hi)\b", 0.9, "Ordinary conversational wording"),
        (r"\b(login successful|logged in successfully|backup (completed|successful)|update(d)? (completed|successfully)|service started|health check (ok|passed))\b", 2.2, "Routine successful system event"),
        (r"\b(your (order|package|invoice|receipt)).{0,30}\b(shipped|delivered|confirmed)\b", 1.2, "Routine order notification"),
    ],
}
COMPILED = {c: [(re.compile(p, re.I), w, r) for p, w, r in rules] for c, rules in RULES.items()}
NORMAL_BIAS = 1.2


def predict_rules(text):
    scores = {c: 0.0 for c in RULES}
    signals = []
    for cls, rules in COMPILED.items():
        for rx, weight, reason in rules:
            m = rx.search(text)
            if m:
                scores[cls] += weight
                signals.append({"class": cls, "reason": reason, "match": m.group(0)[:60]})
    if text.count("!") >= 3:
        scores["Phishing"] += 0.6
        signals.append({"class": "Phishing", "reason": "Excessive exclamation marks", "match": "!!!"})
    letters = [ch for ch in text if ch.isalpha()]
    if len(letters) > 15 and sum(ch.isupper() for ch in letters) / len(letters) > 0.5:
        scores["Phishing"] += 0.6
        signals.append({"class": "Phishing", "reason": "Mostly capital letters (shouting)", "match": "CAPS"})
    logits = dict(scores)
    logits["Normal"] += NORMAL_BIAS
    m = max(logits.values())
    exps = {c: math.exp(v - m) for c, v in logits.items()}
    z = sum(exps.values())
    return {c: v / z for c, v in exps.items()}, signals


# ----------------------------------------------------------------------------------
# API
# ----------------------------------------------------------------------------------
VERDICTS = {
    "Phishing": ("FRAUD / PHISHING", "high", "Do not click links, share codes or send money. Verify through the official website or phone number."),
    "Malware": ("MALWARE RISK", "high", "Do not open or run the file/command. Scan the system and report to your security team."),
    "Intrusion": ("INTRUSION ACTIVITY", "high", "Review the source, block or rate-limit it, and check for compromised accounts."),
    "Normal": ("LOOKS SAFE", "low", "No threat indicators found. Stay cautious with unexpected requests."),
}


def classify(text):
    if _bert is not None:
        probs, signals = predict_bert(text)
        engine = "distilbert-lora"
        if not signals:  # add readable hints from the rule engine for the UI
            signals = predict_rules(text)[1]
    else:
        probs, signals = predict_rules(text)
        engine = "rules"
    top = max(probs, key=probs.get)
    verdict, risk, advice = VERDICTS.get(top, VERDICTS["Normal"])
    if risk == "high" and probs[top] < 0.5:
        risk = "medium"
    return {
        "label": top, "verdict": verdict, "risk": risk, "advice": advice,
        "confidence": min(round(probs[top] * 100, 1), 99.9),
        "probabilities": {c: round(p * 100, 1) for c, p in sorted(probs.items(), key=lambda kv: -kv[1])},
        "signals": signals[:8], "engine": engine,
    }


@app.get("/")
def index():
    return render_template("index.html", max_chars=MAX_CHARS)


@app.get("/api/health")
def health():
    return jsonify(status="ok", engine="distilbert-lora" if _bert else "rules")


@app.post("/api/predict")
def predict():
    data = request.get_json(silent=True) or {}
    text = (data.get("text") or "").strip()
    if not text:
        return jsonify(error="Please enter some text to analyse."), 400
    if len(text) > MAX_CHARS:
        return jsonify(error=f"Text is too long (max {MAX_CHARS} characters)."), 413
    return jsonify(classify(text))


_bert = load_bert()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
